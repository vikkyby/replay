The libtcpedit plugin developer guide is available on the Tcpreplay wiki:
http://tcpreplay.synfin.net/trac/wiki/tcpeditDeveloper

If you have any questions or problems, please contact the tcpreplay-users
mailing list:

https://lists.sourceforge.net/lists/listinfo/tcpreplay-users

Thanks,
Aaron
